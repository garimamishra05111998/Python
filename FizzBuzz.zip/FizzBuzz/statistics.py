
# statistics.py
from collections import Counter

request_counter = Counter()

def track_request(int1, int2, limit, str1, str2):
    request_counter[(int1, int2, limit, str1, str2)] += 1

def get_statistics():
    most_frequent_request, count = request_counter.most_common(1)[0]

    return {
        'most_frequent_request': {
            'int1': most_frequent_request[0],
            'int2': most_frequent_request[1],
            'limit': most_frequent_request[2],
            'str1': most_frequent_request[3],
            'str2': most_frequent_request[4],
            'count': count
        }
    }
