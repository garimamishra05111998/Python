# test_app.py
import unittest
from unittest.mock import patch
from app import app
import json

class TestApp(unittest.TestCase):
    def setUp(self):
        self.app = app.test_client()

    def test_index_route(self):
        # Test the index route
        response = self.app.get('/')
        self.assertEqual(response.status_code, 200)

    def test_fizzbuzz_route(self):
        # Test the FizzBuzz route with valid input
        response = self.app.post('/', data=dict(int1=3, int2=5, limit=15, str1='Fizz', str2='Buzz'))
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'1, 2, Fizz, 4, Buzz, Fizz, 7, 8, Fizz, Buzz, 11, Fizz, 13, 14, FizzBuzz', response.data)

        # Test the FizzBuzz route with invalid input (missing parameters)
        response = self.app.post('/')
        self.assertEqual(response.status_code, 400)  # Assuming your application returns a 400 for bad requests

        def test_fizzbuzz_large_limit(self):
            # Test the FizzBuzz route with a large limit
            response = self.app.post('/', data=dict(int1=3, int2=5, limit=1000, str1='Fizz', str2='Buzz'))
            self.assertEqual(response.status_code, 200)
            # Check if the response contains expected FizzBuzz values for a large limit
            self.assertIn(b'Fizz', response.data)
            self.assertIn(b'Buzz', response.data)

        def test_fizzbuzz_invalid_input(self):
            # Test the FizzBuzz route with invalid input (negative limit)
            response = self.app.post('/', data=dict(int1=3, int2=5, limit=-10, str1='Fizz', str2='Buzz'))
            self.assertEqual(response.status_code, 400)  # Assuming your application returns a 400 for bad requests
            # Check if the response contains an error message or appropriate indication of the bad request

        def test_fizzbuzz_no_multiples(self):
            # Test the FizzBuzz route with parameters where no multiples will be replaced
            response = self.app.post('/', data=dict(int1=7, int2=11, limit=15, str1='Fizz', str2='Buzz'))
            self.assertEqual(response.status_code, 200)
            # Check if the response contains numbers without any 'Fizz', 'Buzz', or 'FizzBuzz'

    @patch('app.get_statistics')  # Mock the function that fetches statistics
    def test_statistics_route(self, mock_get_statistics):
        # Mock the return value of get_statistics for testing
        expected_response = {'most_used_request': {'int1': 3, 'int2': 5, 'limit': 100, 'str1': 'Fizz', 'str2': 'Buzz'},
                             'hits': 42}
        mock_get_statistics.return_value = expected_response

        # Test the statistics route
        response = self.app.get('/statistics')
        self.assertEqual(response.status_code, 200)

        # Convert response data to dictionary for easier comparison
        actual_response = json.loads(response.data)

        # Compare dictionaries instead of raw strings
        self.assertDictEqual(expected_response, actual_response)
    @patch('app.get_statistics')  # Mock the function that fetches statistics
    def test_statistics_route_empty_data(self, mock_get_statistics):
        # Test the statistics route when there is no data (empty response)
        mock_get_statistics.return_value = {}
        response = self.app.get('/statistics')
        self.assertEqual(response.status_code, 200)
        # Check if the response contains an appropriate message or indication for no statistics data

    @patch('app.get_statistics')  # Mock the function that fetches statistics
    def test_statistics_route_multiple_most_used(self, mock_get_statistics):
        # Test the statistics route with multiple most used requests
        expected_response = {
            'most_used_request': {'int1': 3, 'int2': 5, 'limit': 100, 'str1': 'Fizz', 'str2': 'Buzz'},
            'hits': 42
        }
        # Assuming your application can handle multiple most used requests
        mock_get_statistics.return_value = [
            expected_response,
            {'most_used_request': {'int1': 7, 'int2': 11, 'limit': 50, 'str1': 'Foo', 'str2': 'Bar'}, 'hits': 30}
        ]
        response = self.app.get('/statistics')
        self.assertEqual(response.status_code, 200)
        # Check if the response contains the expected statistics data for multiple most used requests


if __name__ == '__main__':
    unittest.main()

    def test_nonexistent_route(self):
        # Test a route that doesn't exist
        response = self.app.get('/nonexistent')
        self.assertEqual(response.status_code, 404)

if __name__ == '__main__':
    unittest.main()
