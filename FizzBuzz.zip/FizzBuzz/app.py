from flask import Flask, render_template, request, jsonify
from statistics import track_request, get_statistics
from flask_wtf import FlaskForm
from wtforms import IntegerField, StringField, SubmitField
from wtforms.validators import DataRequired, NumberRange


app = Flask(__name__,static_url_path='/static')
app.config['SECRET_KEY'] = 'your_secret_key'  # Replace with a secret key

class FizzBuzzForm(FlaskForm):
    int1 = IntegerField('Enter first integer value', validators=[DataRequired(), NumberRange(min=1)])
    int2 = IntegerField('Enter second integer value', validators=[DataRequired(), NumberRange(min=1)])
    limit = IntegerField('Enter limit', validators=[DataRequired(), NumberRange(min=1)])
    str1 = StringField('Enter first string value', validators=[DataRequired()])
    str2 = StringField('Enter second string value', validators=[DataRequired()])
    submit = SubmitField('FIZZBUZZ LOGIC SUBMIT')

@app.route("/")
def index():
    form = FizzBuzzForm()
    if form.validate_on_submit():
        # Form is valid, process the FizzBuzz logic
        value_1 = form.int1.data
        value_2 = form.int2.data
        limit = form.limit.data
        string_1 = form.str1.data
        string_2 = form.str2.data
        result = ""
        for i in range(1, limit + 1):
            output = ""
            if i % value_1 == 0:
                output += string_1
            if i % value_2 == 0:
                output += string_2
            result = result + (output or str(i)) + ", "
        return render_template('result.html', r=result[:-2])
    return render_template('index.html', form=form)

@app.route("/", methods=['POST'])
def getvalue():
    value_1 = int(request.form["int1"])
    value_2 = int(request.form["int2"])
    limit = int(request.form["limit"])
    string_1 = str(request.form["str1"])
    string_2 = str(request.form["str2"])
    # Track the request for statistics
    track_request(value_1, value_2, limit, string_1, string_2)
    i = ""
    result = ""
    for i in range(1, limit + 1):
       output = ""
       if i % value_1 == 0:
           output += string_1
       if i % value_2 == 0:
           output += string_2
       result=result+(output or str(i))+", "
    return render_template('result.html', r=result[:-2])

@app.route('/statistics', methods=['GET'])
def statistics_endpoint():
    return jsonify(get_statistics())

if __name__ == '__main__':
    from waitress import server
    app.run(debug=True, port=8000)


